package com.loobo.thrift_hello_world;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThriftHelloWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThriftHelloWorldApplication.class, args);
	}
}
